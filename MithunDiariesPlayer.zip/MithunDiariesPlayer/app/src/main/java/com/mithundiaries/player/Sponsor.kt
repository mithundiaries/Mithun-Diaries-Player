package com.mithundiaries.player

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.graphics.BitmapFactory
import android.net.Uri
import android.widget.ImageView
import android.widget.Toast
import androidx.core.graphics.drawable.RoundedBitmapDrawableFactory

const val SUBSCRIBE_URL = "https://www.youtube.com/@mithundiaries?sub_confirmation=1"

fun Context.openSubscribeLink() {
    try {
        startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(SUBSCRIBE_URL)))
    } catch (e: ActivityNotFoundException) {
        Toast.makeText(this, R.string.no_browser, Toast.LENGTH_LONG).show()
    }
}

fun ImageView.showCircularSponsorImage() {
    val bitmap = BitmapFactory.decodeResource(resources, R.drawable.mithun_diaries)
    val round = RoundedBitmapDrawableFactory.create(resources, bitmap)
    round.isCircular = true
    setImageDrawable(round)
}
