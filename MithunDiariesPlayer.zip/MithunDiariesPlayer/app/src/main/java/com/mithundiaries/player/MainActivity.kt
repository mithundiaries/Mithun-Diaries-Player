package com.mithundiaries.player

import android.Manifest
import android.content.ContentUris
import android.content.pm.PackageManager
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.media.audiofx.BassBoost
import android.media.audiofx.Equalizer
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.BaseAdapter
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SwitchCompat
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import java.util.Locale

data class Song(
    val id: Long,
    val title: String,
    val artist: String,
    val duration: Long,
    val uri: Uri
)

open class SimpleSeek : SeekBar.OnSeekBarChangeListener {
    override fun onProgressChanged(seekBar: SeekBar, progress: Int, fromUser: Boolean) {}
    override fun onStartTrackingTouch(seekBar: SeekBar) {}
    override fun onStopTrackingTouch(seekBar: SeekBar) {}
}

class MainActivity : AppCompatActivity() {

    private val songs = mutableListOf<Song>()
    private var current = -1
    private val player = MediaPlayer()
    private var prepared = false
    private var userSeeking = false

    private var equalizer: Equalizer? = null
    private var bassBoost: BassBoost? = null
    private val bandSeekBars = mutableListOf<SeekBar>()

    private val handler = Handler(Looper.getMainLooper())
    private val prefs by lazy { getSharedPreferences("sound", MODE_PRIVATE) }

    private lateinit var adapter: SongAdapter
    private lateinit var songList: ListView
    private lateinit var emptyText: TextView
    private lateinit var nowTitle: TextView
    private lateinit var nowArtist: TextView
    private lateinit var seekProgress: SeekBar
    private lateinit var tvElapsed: TextView
    private lateinit var tvDuration: TextView
    private lateinit var btnPlay: ImageButton
    private lateinit var eqPanel: ScrollView
    private lateinit var btnEqToggle: TextView
    private lateinit var switchFx: SwitchCompat
    private lateinit var seekBass: SeekBar
    private lateinit var seekTreble: SeekBar
    private lateinit var tvBassVal: TextView
    private lateinit var tvTrebleVal: TextView
    private lateinit var presetSpinner: Spinner
    private lateinit var eqBands: LinearLayout
    private lateinit var eqUnavailable: TextView

    private val audioPermission: String =
        if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO
        else Manifest.permission.READ_EXTERNAL_STORAGE

    private val progressUpdater = object : Runnable {
        override fun run() {
            if (prepared && !userSeeking) {
                val pos = player.currentPosition
                seekProgress.progress = pos
                tvElapsed.text = formatTime(pos.toLong())
            }
            handler.postDelayed(this, 500)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        bindViews()
        setupHeader()
        setupPlayer()
        setupControls()
        setupEffects()

        // Back button sends the app to the background so music keeps playing
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                moveTaskToBack(true)
            }
        })

        if (hasAudioPermission()) {
            loadSongs()
        } else {
            ActivityCompat.requestPermissions(this, arrayOf(audioPermission), REQ_AUDIO)
        }

        handler.post(progressUpdater)
    }

    // ---------- Setup ----------

    private fun bindViews() {
        songList = findViewById(R.id.songList)
        emptyText = findViewById(R.id.emptyText)
        nowTitle = findViewById(R.id.nowTitle)
        nowArtist = findViewById(R.id.nowArtist)
        seekProgress = findViewById(R.id.seekProgress)
        tvElapsed = findViewById(R.id.tvElapsed)
        tvDuration = findViewById(R.id.tvDuration)
        btnPlay = findViewById(R.id.btnPlay)
        eqPanel = findViewById(R.id.eqPanel)
        btnEqToggle = findViewById(R.id.btnEqToggle)
        switchFx = findViewById(R.id.switchFx)
        seekBass = findViewById(R.id.seekBass)
        seekTreble = findViewById(R.id.seekTreble)
        tvBassVal = findViewById(R.id.tvBassVal)
        tvTrebleVal = findViewById(R.id.tvTrebleVal)
        presetSpinner = findViewById(R.id.presetSpinner)
        eqBands = findViewById(R.id.eqBands)
        eqUnavailable = findViewById(R.id.eqUnavailable)
    }

    private fun setupHeader() {
        findViewById<ImageView>(R.id.headerAvatar).showCircularSponsorImage()
        findViewById<TextView>(R.id.btnHeaderSubscribe).setOnClickListener { openSubscribeLink() }
    }

    private fun setupPlayer() {
        player.setOnPreparedListener { mp ->
            prepared = true
            mp.start()
            seekProgress.max = mp.duration
            tvDuration.text = formatTime(mp.duration.toLong())
            equalizer?.enabled = switchFx.isChecked
            bassBoost?.enabled = switchFx.isChecked
            updatePlayButton()
        }
        player.setOnCompletionListener {
            if (prepared) playNext()
        }
        player.setOnErrorListener { _, _, _ ->
            prepared = false
            Toast.makeText(this, R.string.cant_play, Toast.LENGTH_SHORT).show()
            updatePlayButton()
            true
        }
    }

    private fun setupControls() {
        adapter = SongAdapter()
        songList.adapter = adapter
        songList.setOnItemClickListener { _, _, position, _ -> playSong(position) }

        btnPlay.setOnClickListener { togglePlay() }
        findViewById<ImageButton>(R.id.btnNext).setOnClickListener { playNext() }
        findViewById<ImageButton>(R.id.btnPrev).setOnClickListener { playPrevious() }

        seekProgress.setOnSeekBarChangeListener(object : SimpleSeek() {
            override fun onProgressChanged(seekBar: SeekBar, progress: Int, fromUser: Boolean) {
                if (fromUser) tvElapsed.text = formatTime(progress.toLong())
            }
            override fun onStartTrackingTouch(seekBar: SeekBar) {
                userSeeking = true
            }
            override fun onStopTrackingTouch(seekBar: SeekBar) {
                userSeeking = false
                if (prepared) player.seekTo(seekBar.progress)
            }
        })

        btnEqToggle.setOnClickListener {
            val show = eqPanel.visibility != View.VISIBLE
            eqPanel.visibility = if (show) View.VISIBLE else View.GONE
            btnEqToggle.setText(if (show) R.string.equalizer_hide else R.string.equalizer_show)
        }
    }

    // ---------- Bass, treble and equalizer ----------

    private fun setupEffects() {
        val session = player.audioSessionId
        equalizer = try { Equalizer(0, session) } catch (e: Exception) { null }
        bassBoost = try { BassBoost(0, session) } catch (e: Exception) { null }

        val fxOn = prefs.getBoolean("fx", true)
        switchFx.isChecked = fxOn
        setEffectsEnabled(fxOn)
        switchFx.setOnCheckedChangeListener { _, checked ->
            setEffectsEnabled(checked)
            prefs.edit().putBoolean("fx", checked).apply()
        }

        setupBass()
        setupEqualizerAndTreble()
    }

    private fun setEffectsEnabled(on: Boolean) {
        try { equalizer?.enabled = on } catch (_: Exception) {}
        try { bassBoost?.enabled = on } catch (_: Exception) {}
    }

    private fun setupBass() {
        val bb = bassBoost
        if (bb == null || !bb.strengthSupported) {
            seekBass.isEnabled = false
            tvBassVal.setText(R.string.not_available)
            return
        }
        seekBass.max = 1000
        val saved = prefs.getInt("bass", 0)
        seekBass.progress = saved
        applyBass(bb, saved)
        seekBass.setOnSeekBarChangeListener(object : SimpleSeek() {
            override fun onProgressChanged(seekBar: SeekBar, progress: Int, fromUser: Boolean) {
                applyBass(bb, progress)
                prefs.edit().putInt("bass", progress).apply()
            }
        })
    }

    private fun applyBass(bb: BassBoost, strength: Int) {
        try { bb.setStrength(strength.toShort()) } catch (_: Exception) {}
        tvBassVal.text = String.format(Locale.US, "%d%%", strength / 10)
    }

    private fun setupEqualizerAndTreble() {
        val eq = equalizer
        if (eq == null) {
            eqUnavailable.visibility = View.VISIBLE
            seekTreble.isEnabled = false
            presetSpinner.isEnabled = false
            tvTrebleVal.setText(R.string.not_available)
            return
        }

        val range = eq.bandLevelRange
        val minLevel = range[0].toInt()
        val maxLevel = range[1].toInt()
        val bandCount = eq.numberOfBands.toInt()

        // One slider per equalizer band
        for (b in 0 until bandCount) {
            val band = b.toShort()
            val row = layoutInflater.inflate(R.layout.item_band, eqBands, false)
            val label = row.findViewById<TextView>(R.id.bandLabel)
            val value = row.findViewById<TextView>(R.id.bandValue)
            val seek = row.findViewById<SeekBar>(R.id.bandSeek)

            label.text = formatFreq(eq.getCenterFreq(band))
            seek.max = maxLevel - minLevel

            val saved = prefs.getInt("band_$b", eq.getBandLevel(band).toInt())
                .coerceIn(minLevel, maxLevel)
            seek.progress = saved - minLevel
            setBand(eq, band, saved)
            value.text = formatDb(saved)

            seek.setOnSeekBarChangeListener(object : SimpleSeek() {
                override fun onProgressChanged(seekBar: SeekBar, progress: Int, fromUser: Boolean) {
                    val level = progress + minLevel
                    setBand(eq, band, level)
                    value.text = formatDb(level)
                    prefs.edit().putInt("band_$b", level).apply()
                    if (fromUser) presetSpinner.setSelection(0)
                }
            })
            eqBands.addView(row)
            bandSeekBars.add(seek)
        }

        // Presets from the phone's audio engine (Rock, Pop, Jazz...)
        val names = mutableListOf(getString(R.string.custom))
        for (i in 0 until eq.numberOfPresets) names.add(eq.getPresetName(i.toShort()))
        val presetAdapter = ArrayAdapter(this, R.layout.item_spinner, names)
        presetAdapter.setDropDownViewResource(R.layout.item_spinner_dropdown)
        presetSpinner.adapter = presetAdapter
        presetSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                if (position == 0) return
                try {
                    eq.usePreset((position - 1).toShort())
                } catch (_: Exception) {
                    return
                }
                for (b in bandSeekBars.indices) {
                    bandSeekBars[b].progress = eq.getBandLevel(b.toShort()) - minLevel
                }
            }
            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }

        // Treble drives the high-frequency bands (3 kHz and above)
        var trebleBands = (0 until bandCount).filter { eq.getCenterFreq(it.toShort()) >= 3_000_000 }
        if (trebleBands.isEmpty() && bandCount > 0) trebleBands = listOf(bandCount - 1)

        seekTreble.max = 100
        val savedTreble = prefs.getInt("treble", 50)
        seekTreble.progress = savedTreble
        tvTrebleVal.text = formatDb(trebleLevel(savedTreble, maxLevel))
        seekTreble.setOnSeekBarChangeListener(object : SimpleSeek() {
            override fun onProgressChanged(seekBar: SeekBar, progress: Int, fromUser: Boolean) {
                val level = trebleLevel(progress, maxLevel).coerceIn(minLevel, maxLevel)
                trebleBands.forEach { bandSeekBars[it].progress = level - minLevel }
                tvTrebleVal.text = formatDb(level)
                prefs.edit().putInt("treble", progress).apply()
                if (fromUser) presetSpinner.setSelection(0)
            }
        })
    }

    /** 0..100 slider, 50 is flat. Maps to -max..+max millibels. */
    private fun trebleLevel(progress: Int, maxLevel: Int): Int =
        ((progress - 50) / 50f * maxLevel).toInt()

    private fun setBand(eq: Equalizer, band: Short, level: Int) {
        try { eq.setBandLevel(band, level.toShort()) } catch (_: Exception) {}
    }

    // ---------- Playback ----------

    private fun playSong(index: Int) {
        if (index !in songs.indices) return
        current = index
        val song = songs[index]
        prepared = false
        try {
            player.reset()
            player.setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build()
            )
            player.setDataSource(this, song.uri)
            player.prepareAsync()
        } catch (e: Exception) {
            Toast.makeText(this, R.string.cant_play, Toast.LENGTH_SHORT).show()
        }
        nowTitle.text = song.title
        nowArtist.text = song.artist
        seekProgress.progress = 0
        tvElapsed.text = formatTime(0)
        tvDuration.text = formatTime(song.duration)
        adapter.notifyDataSetChanged()
        updatePlayButton()
    }

    private fun togglePlay() {
        if (!prepared) {
            if (current == -1 && songs.isNotEmpty()) playSong(0)
            return
        }
        if (player.isPlaying) player.pause() else player.start()
        updatePlayButton()
    }

    private fun playNext() {
        if (songs.isEmpty()) return
        playSong((current + 1) % songs.size)
    }

    private fun playPrevious() {
        if (songs.isEmpty()) return
        if (prepared && player.currentPosition > 3000) {
            player.seekTo(0)
            return
        }
        playSong(if (current <= 0) songs.size - 1 else current - 1)
    }

    private fun updatePlayButton() {
        val playing = prepared && player.isPlaying
        btnPlay.setImageResource(if (playing) R.drawable.ic_pause else R.drawable.ic_play)
    }

    // ---------- Songs on the phone ----------

    private fun hasAudioPermission(): Boolean =
        ContextCompat.checkSelfPermission(this, audioPermission) == PackageManager.PERMISSION_GRANTED

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode != REQ_AUDIO) return
        if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            loadSongs()
        } else {
            emptyText.setText(R.string.need_permission)
            emptyText.visibility = View.VISIBLE
        }
    }

    private fun loadSongs() {
        songs.clear()
        val collection = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        val projection = arrayOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.ARTIST,
            MediaStore.Audio.AudioColumns.DURATION
        )
        try {
            contentResolver.query(
                collection,
                projection,
                "${MediaStore.Audio.Media.IS_MUSIC} != 0",
                null,
                "${MediaStore.Audio.Media.TITLE} COLLATE NOCASE ASC"
            )?.use { c ->
                val idCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
                val titleCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
                val artistCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
                val durCol = c.getColumnIndexOrThrow(MediaStore.Audio.AudioColumns.DURATION)
                while (c.moveToNext()) {
                    val id = c.getLong(idCol)
                    val artist = c.getString(artistCol)
                        ?.takeIf { it.isNotBlank() && it != "<unknown>" } ?: "Unknown artist"
                    songs.add(
                        Song(
                            id = id,
                            title = c.getString(titleCol) ?: "Unknown",
                            artist = artist,
                            duration = c.getLong(durCol),
                            uri = ContentUris.withAppendedId(collection, id)
                        )
                    )
                }
            }
        } catch (e: Exception) {
            // Leave the list empty; the message below explains what to do
        }
        adapter.notifyDataSetChanged()
        if (songs.isEmpty()) {
            emptyText.setText(R.string.no_songs)
            emptyText.visibility = View.VISIBLE
        } else {
            emptyText.visibility = View.GONE
        }
    }

    inner class SongAdapter : BaseAdapter() {
        override fun getCount(): Int = songs.size
        override fun getItem(position: Int): Any = songs[position]
        override fun getItemId(position: Int): Long = songs[position].id

        override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
            val view = convertView ?: layoutInflater.inflate(R.layout.item_song, parent, false)
            val song = songs[position]
            val title = view.findViewById<TextView>(R.id.songTitle)
            title.text = song.title
            title.setTextColor(
                ContextCompat.getColor(
                    this@MainActivity,
                    if (position == current) R.color.red else R.color.text
                )
            )
            view.findViewById<TextView>(R.id.songArtist).text =
                "${song.artist}  ${formatTime(song.duration)}"
            return view
        }
    }

    // ---------- Helpers ----------

    private fun formatTime(ms: Long): String {
        val total = ms / 1000
        return String.format(Locale.US, "%d:%02d", total / 60, total % 60)
    }

    private fun formatFreq(milliHz: Int): String {
        val hz = milliHz / 1000
        return if (hz >= 1000) String.format(Locale.US, "%.1f kHz", hz / 1000f) else "$hz Hz"
    }

    private fun formatDb(milliBel: Int): String =
        String.format(Locale.US, "%+.1f dB", milliBel / 100f)

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        try { equalizer?.release() } catch (_: Exception) {}
        try { bassBoost?.release() } catch (_: Exception) {}
        player.release()
        super.onDestroy()
    }

    companion object {
        private const val REQ_AUDIO = 42
    }
}
